package com.example.utils;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

import com.example.schedular.CafeOccupancySchedular;

public class ServletInitializer extends SpringBootServletInitializer{
	
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application)
	{
		CafeOccupancySchedular.startInsertingPeopleCount();
		return application;
		
	}
}
