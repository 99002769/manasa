package com.example.schedular;

import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

import com.example.controller.CafeteriaController;
import com.example.service.CafeteriaService;

public class CafeSchedularJob implements Job{
	int  peoplecount;
	private static final Logger logger = LogManager.getLogger(CafeSchedularJob.class);
	@Autowired
	private SessionFactory sessionFactory;
    
	@Autowired
	CafeteriaService cafeteriaService;
	@Autowired
	CafeteriaController cafe;

	public CafeteriaService getCafeteriaService() {
		return cafeteriaService;
	}

	public void setCafeteriaService(CafeteriaService cafeteriaService) {
		this.cafeteriaService = cafeteriaService;
	}

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		
		logger.info("Schedular Job is running...");
		
		try {

			Random rand = new Random();
			int selected = rand.nextInt(100);
			 Session session = this.sessionFactory.getCurrentSession();
			    String hql;
			hql="insert into cafeOccupancyBase(id)values(selected)";
			
			

		} catch (Exception e) {
			logger.debug(":execute()-AppointmentStatus error: ", e);
		}
	
		
	}
	@Scheduled(initialDelayString="${TIMEOUT_SCHEDULER_INTIAL_DELAY}",
            fixedRateString="${TIMEOUT_SCHEDULER_DELAY}")
	public void postingdata() {
		System.out.println("hiiiii");
		cafe.save();
	}
	
	
}
