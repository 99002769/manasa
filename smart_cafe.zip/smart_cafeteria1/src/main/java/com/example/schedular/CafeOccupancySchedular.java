package com.example.schedular;



import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

public class CafeOccupancySchedular {
	final static Logger LOGGER = LogManager.getLogger(CafeOccupancySchedular.class);

	public static void startInsertingPeopleCount() {
		String runStatus ="TRUE";
		if (runStatus.equalsIgnoreCase("TRUE")) {
			new CafeSchedular().configureScheduler("update schedule", "VendorAppointmentTrigger",
					"vendorAppointmentGroup", "0 * */1 ? * *", CafeSchedularJob.class);
		}
	}
}
