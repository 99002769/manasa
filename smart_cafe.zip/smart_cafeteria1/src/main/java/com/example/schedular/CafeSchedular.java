package com.example.schedular;

import java.util.TimeZone;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.quartz.CronScheduleBuilder;
import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

public class CafeSchedular {
	
	final static Logger LOGGER = LogManager.getLogger(CafeSchedular.class);
	
public void configureScheduler(String jobName, String triggerName, String groupName, String cronExpression, Class<? extends Job> jobClass) {
		
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("In configureScheduler(). Parameters -" +
					" jobName: " + jobName + 
					" triggerName: " + triggerName +
					" groupName" + groupName +
					" cronExpression" + cronExpression +
					" jobClass Name" + jobClass.getName()); 
		}
		
		JobDetail job = JobBuilder.newJob(jobClass)
      			.withIdentity(jobName, groupName) 
      			.build();
		
		
		
			
		

		Trigger trigger = TriggerBuilder.newTrigger()
				.withIdentity(triggerName, groupName)
				.withSchedule(CronScheduleBuilder.cronSchedule(cronExpression).inTimeZone(TimeZone.getTimeZone("GMT+5:30")))
				.build();

		try {
			Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
			scheduler.scheduleJob(job, trigger);
			scheduler.start();
		}
		catch (SchedulerException e) {
			LOGGER.error("Exception in creating Scheduler in configureScheduler(). Exception: " + e);
		}
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Exiting configureScheduler()");
		}
	}
	
}
